# Integrations

Integrations are components that provide integration to other services in the Castle stack. At present there are two integrations available in MonoRail:

* [ActiveRecord Integration](activerecord-integration.md)
* [Windsor Integration](windsor-integration.md)