using System;

namespace NetReflectorPluginTest
{
	// this class should not be loaded by NetReflector
	public class Nothing
	{
	}
}
