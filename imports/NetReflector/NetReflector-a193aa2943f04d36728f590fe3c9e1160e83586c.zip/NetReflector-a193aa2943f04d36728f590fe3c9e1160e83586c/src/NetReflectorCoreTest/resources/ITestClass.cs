using System;

namespace NetReflectorCoreTest
{
	public interface ITestClass
	{
	}
}
