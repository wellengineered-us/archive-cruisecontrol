using System;

namespace Exortech.NetReflector.Test
{
	public interface ITestClass
	{
	}
}
