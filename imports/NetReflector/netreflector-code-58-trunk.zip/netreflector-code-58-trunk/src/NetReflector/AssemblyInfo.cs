using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Security.Permissions;

// Assembly metadata
[assembly : AssemblyTitle("NetReflector")]
[assembly : AssemblyDescription("NetReflector is an open source xml binding framework.")]
[assembly : NeutralResourcesLanguage("en")]
[assembly : CLSCompliant(true)]
[assembly : ComVisible(false)]

// Permissions
[assembly : FileIOPermission(SecurityAction.RequestMinimum)]
[assembly : ReflectionPermission(SecurityAction.RequestMinimum)]