More information about NVelocity can be found at [docs/nvelocity.md](docs/nvelocity.md)
