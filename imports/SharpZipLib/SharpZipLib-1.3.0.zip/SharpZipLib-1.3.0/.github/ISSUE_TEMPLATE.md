### Steps to reproduce
1.
2.
3.

### Expected behavior
Tell us what should happen

### Actual behavior
Tell us what happens instead

### Version of SharpZipLib

### Obtained from (only keep the relevant lines)
- Compiled from source, commit: _______
- Downloaded from GitHub
- Package installed using NuGet
