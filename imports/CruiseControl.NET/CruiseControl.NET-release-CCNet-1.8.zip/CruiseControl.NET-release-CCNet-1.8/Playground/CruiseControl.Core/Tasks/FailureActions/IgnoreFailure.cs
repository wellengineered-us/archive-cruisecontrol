﻿namespace CruiseControl.Core.Tasks.FailureActions
{
    public class IgnoreFailure
        : TaskFailureAction
    {
    }
}
