﻿namespace CruiseControl.Core
{
    /// <summary>
    /// Defines a modification from a source control block.
    /// </summary>
    public class Modification
    {
    }
}
