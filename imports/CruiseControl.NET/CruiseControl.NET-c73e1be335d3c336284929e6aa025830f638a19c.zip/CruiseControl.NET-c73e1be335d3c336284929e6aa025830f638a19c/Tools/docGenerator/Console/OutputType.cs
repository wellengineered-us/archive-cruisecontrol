﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console
{
    public enum OutputType
    {
        Info,
        Debug,
        Warning,
        Error,
    }
}
