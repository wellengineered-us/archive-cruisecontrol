Stub readme.
